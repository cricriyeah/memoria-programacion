// Cristofer Jimenez Fernandez, IDS, turno matutino
//Hacer un codigo que imprima un numero y un caracter ingresados por el usuario
#include <iostream>

using namespace std;
double num;
char carac;
int main()
{
    cout << "Hola usuario, por favor ingrese un numero y un caracter." << endl;
    cin >> num;
    cin >> carac;
    cout << num;
    cout << carac;


 return 0;
}
