//Cristofer Jimenez Fernandez
//IDS turno matutino, 2do semestre
//crear un codigo que convierta un caracter a su valor entero con conversion implicita

#include <iostream>

using namespace std;

int main()
{
    char caracter;
    cin>> caracter;
    cout << (int)caracter;
    return 0;
}
