// Cristofer Jimenez Fernandez, IDS, turno matutino
//Hacer un codigo que imprima una descripcion sobre mi con almenos una secuencia de escape
#include <iostream>

using namespace std;

int main()
{
    cout << "Hola, mi nombre es Cristofer Jimenez Fernandez,"  "\ntengo 18 a�os de edad y me gusta mucho dibujar en mi tiempo libre." "\nEstoy estudiando la carrera de ingieneria en desarrollo de software y voy en segundo semestre" << endl;
    return 0;
}
